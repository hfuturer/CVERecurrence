import com.opensymphony.xwork2.ActionSupport;

public class Payload extends ActionSupport {

	public String execute(){
		return SUCCESS;
	}
	
	public String payload = "";

	public String getPayload() {
		return this.payload;
	}

	public void setPayload() {
		this.payload = payload;
	}
}
